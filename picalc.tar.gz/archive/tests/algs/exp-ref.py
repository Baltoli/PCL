try:
    x = int(input("> "))
    y = int(input("> "))
    print(x**y)
    while True: pass
except:
    pass
