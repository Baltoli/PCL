from fractions import gcd
a = int(input("> "))
b = int(input("> "))
print(gcd(a,b))
