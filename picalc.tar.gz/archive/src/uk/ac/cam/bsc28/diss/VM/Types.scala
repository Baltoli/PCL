package uk.ac.cam.bsc28.diss.VM

object Types {
  type Atom = Either[Channel, Long]
}
